"""Generate the deterministic machine-readable evidence bundle."""

from __future__ import annotations

import argparse
import csv
import json
import os
import platform
import sys
from pathlib import Path
from typing import Any

import numpy as np

from diffusion_gmm_repro.audit import (
    run_dimension_audit,
    run_jacobian_audit,
    run_score_error_audit,
)

PAPER_ID = "HMu24dTKkJ"
PAPER_REVISION = "arxiv:2504.05300v1"


def _dimensions(value: str) -> tuple[int, ...]:
    try:
        dimensions = tuple(int(item) for item in value.split(","))
    except ValueError as error:
        raise argparse.ArgumentTypeError("dimensions must be comma-separated integers") from error
    if not dimensions or any(dimension <= 0 for dimension in dimensions):
        raise argparse.ArgumentTypeError("dimensions must be positive")
    return dimensions


def _claim_results(
    dimension_rows: list[dict[str, object]],
    score_rows: list[dict[str, object]],
    jacobian_rows: list[dict[str, object]],
) -> list[dict[str, object]]:
    dimension_errors = [
        float(row["analytic_per_coordinate_variance_error"])
        for row in dimension_rows
    ]
    dimension_range = max(dimension_errors) - min(dimension_errors)
    in_scope_score_rows = [
        row for row in score_rows if bool(row["assumption_satisfied"])
    ]
    shifts = [float(row["analytic_mean_shift_l2"]) for row in in_scope_score_rows]
    monotone = all(left <= right for left, right in zip(shifts, shifts[1:]))
    baseline_traces = [
        float(row["max_trace_i_plus_j"])
        for row in jacobian_rows
        if bool(row["assumption_satisfied"])
    ]
    controls = [
        abs(float(row["mean_trace_i_plus_j"]))
        for row in jacobian_rows
        if not bool(row["assumption_satisfied"])
    ]
    jacobian_range = max(baseline_traces) - min(baseline_traces)
    control_separates = min(controls) > max(baseline_traces)
    return [
        {
            "claim_id": "dimension-free-ddpm-discretization",
            "status": "supports" if dimension_range <= 1e-12 else "does-not-support",
            "threshold": "range of analytic per-coordinate variance error <= 1e-12",
            "observations": {
                "dimensions": [row["dimension"] for row in dimension_rows],
                "analytic_error_range": dimension_range,
            },
            "scope": "one exact-score Euler/DDPM step at a stationary standard Gaussian",
        },
        {
            "claim_id": "robustness-to-score-error",
            "status": "supports" if monotone else "does-not-support",
            "threshold": "analytic mean shift is nondecreasing in additive score-error norm",
            "observations": {
                "score_error_l2": [
                    row["score_error_l2"] for row in in_scope_score_rows
                ],
                "analytic_mean_shift_l2": shifts,
            },
            "scope": "controlled constant additive score error in one Gaussian step",
        },
        {
            "claim_id": "dimension-free-score-jacobian-trace",
            "status": (
                "supports"
                if jacobian_range <= 1e-12 and control_separates
                else "does-not-support"
            ),
            "threshold": (
                "baseline tr(I+J) range <= 1e-12 and every "
                "unit-covariance control exceeds baseline"
            ),
            "observations": {
                "baseline_trace_range": jacobian_range,
                "assumption_breaking_control_separates": control_separates,
            },
            "scope": "analytic two-component isotropic-GMM score with a unit-covariance violation control",
        },
    ]


def build_bundle(
    *, dimensions: tuple[int, ...], seed: int, samples: int
) -> tuple[dict[str, Any], list[dict[str, object]]]:
    dimension_rows = run_dimension_audit(
        dimensions=dimensions, seed=seed, samples=samples
    )
    score_rows = run_score_error_audit(
        dimension=max(dimensions), seed=seed, samples=samples
    )
    jacobian_rows = run_jacobian_audit(
        dimensions=dimensions, seed=seed, samples=samples
    )
    audits = {
        "dimension": dimension_rows,
        "score_error": score_rows,
        "jacobian": jacobian_rows,
    }
    measurements: list[dict[str, object]] = []
    claim_for_audit = {
        "dimension": "dimension-free-ddpm-discretization",
        "score_error": "robustness-to-score-error",
        "jacobian": "dimension-free-score-jacobian-trace",
    }
    for audit_name, rows in audits.items():
        for index, row in enumerate(rows):
            measurements.append(
                {
                    "claim_id": claim_for_audit[audit_name],
                    "audit": audit_name,
                    "record_index": index,
                    "source": "this-code",
                    "observation_json": json.dumps(
                        row, sort_keys=True, separators=(",", ":")
                    ),
                }
            )
    bundle: dict[str, Any] = {
        "schema_version": 1,
        "evidence_kind": "independent-numerical-audit",
        "paper": {
            "id": PAPER_ID,
            "revision": PAPER_REVISION,
            "title": "Dimension-Free Convergence of Diffusion Models for Approximate Gaussian Mixtures",
        },
        "paper_context": {
            "source": "paper",
            "note": "The theorem claims define audit targets; paper values are not reproduced measurements.",
        },
        "computed_outputs": {"source": "this-code", "audits": audits},
        "claims": _claim_results(dimension_rows, score_rows, jacobian_rows),
        "parameters": {
            "dimensions": list(dimensions),
            "samples": samples,
            "seed": seed,
        },
        "environment": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "platform": platform.platform(),
        },
        "provenance_file": "provenance.json",
    }
    return bundle, measurements


def _atomic_write(path: Path, content: str) -> None:
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(content, encoding="utf-8")
    os.replace(temporary, path)


def write_bundle(output_dir: Path, bundle: dict[str, Any], rows: list[dict[str, object]]) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    _atomic_write(output_dir / "results.json", json.dumps(bundle, indent=2, sort_keys=True) + "\n")
    temporary_csv = output_dir / ".measurements.csv.tmp"
    with temporary_csv.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=["claim_id", "audit", "record_index", "source", "observation_json"],
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)
    os.replace(temporary_csv, output_dir / "measurements.csv")


def parser() -> argparse.ArgumentParser:
    argument_parser = argparse.ArgumentParser(description=__doc__)
    argument_parser.add_argument("--output-dir", type=Path, default=Path("evidence"))
    argument_parser.add_argument("--dimensions", type=_dimensions, default=(1, 4, 16, 64))
    argument_parser.add_argument("--seed", type=int, default=2026)
    argument_parser.add_argument("--samples", type=int, default=2048)
    return argument_parser


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    if args.samples <= 0:
        parser().error("samples must be positive")
    bundle, rows = build_bundle(
        dimensions=args.dimensions, seed=args.seed, samples=args.samples
    )
    write_bundle(args.output_dir, bundle, rows)
    return 0


if __name__ == "__main__":
    sys.exit(main())
