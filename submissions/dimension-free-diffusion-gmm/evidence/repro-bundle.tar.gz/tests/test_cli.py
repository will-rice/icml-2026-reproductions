from __future__ import annotations

import csv
import json
import subprocess
import sys
from pathlib import Path


CLAIM_IDS = {
    "dimension-free-ddpm-discretization",
    "robustness-to-score-error",
    "dimension-free-score-jacobian-trace",
}


def run_cli(output_dir: Path, *extra_args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [
            sys.executable,
            "-m",
            "diffusion_gmm_repro.cli",
            "--output-dir",
            str(output_dir),
            "--seed",
            "17",
            "--samples",
            "64",
            *extra_args,
        ],
        text=True,
        capture_output=True,
        check=False,
    )


def test_cli_writes_deterministic_schema_complete_bundle(tmp_path: Path) -> None:
    first = tmp_path / "first"
    second = tmp_path / "second"

    assert run_cli(first).returncode == 0
    assert run_cli(second).returncode == 0
    assert (first / "results.json").read_bytes() == (second / "results.json").read_bytes()
    assert (first / "measurements.csv").read_bytes() == (
        second / "measurements.csv"
    ).read_bytes()

    bundle = json.loads((first / "results.json").read_text())
    assert bundle["schema_version"] == 1
    assert bundle["paper"]["revision"] == "arxiv:2504.05300v1"
    assert bundle["evidence_kind"] == "independent-numerical-audit"
    assert {result["claim_id"] for result in bundle["claims"]} == CLAIM_IDS
    assert all(result["status"] in {"supports", "does-not-support"} for result in bundle["claims"])
    assert all(result["observations"] for result in bundle["claims"])
    assert all(result["threshold"] for result in bundle["claims"])
    assert bundle["paper_context"]["source"] == "paper"
    assert bundle["computed_outputs"]["source"] == "this-code"

    with (first / "measurements.csv").open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    assert rows
    assert {row["claim_id"] for row in rows} == CLAIM_IDS
    assert all(row["source"] == "this-code" for row in rows)


def test_cli_rejects_invalid_arguments(tmp_path: Path) -> None:
    result = run_cli(tmp_path / "invalid", "--dimensions", "4,0")

    assert result.returncode != 0
    assert "positive" in result.stderr
    assert not (tmp_path / "invalid" / "results.json").exists()
